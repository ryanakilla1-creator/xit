# FF Sticky Neck Aim (External)

External vision-based sticky aim for Free Fire style games.
Locks onto the neck region of detected targets. No root. No memory write.
Install the APK → grant 3 permissions → open Free Fire → toggle Sticky Neck.

## What it does

- Screen capture (MediaProjection) at half resolution
- Lightweight color + shape detector finds candidate players
- Aim point forced to upper ~22% of the bounding box (neck)
- AccessibilityService injects humanized curved gestures
- Floating control panel: FOV, smoothness, on/off
- Randomized timing + path jitter (anti simple pattern detection)

## Build the APK (one time)

1. Install Android Studio (latest stable)
2. Open the folder `FreeFireAimbot` as a project
3. Let Gradle sync
4. Build → Build Bundle(s) / APK(s) → Build APK(s)
5. APK appears in `app/build/outputs/apk/release/` or `debug/`

Or from terminal (if SDK configured):

```
./gradlew assembleRelease
```

## Install & use (phone)

1. Enable "Install from unknown sources" for your browser/file manager
2. Install the APK
3. Open the app → press the 4 buttons in order:
   - Enable Overlay
   - Enable Accessibility (turn on "System Optimizer")
   - Start Capture (accept the screen share dialog)
   - Start Aim Service
4. Open Free Fire
5. Floating menu appears → turn "Sticky Neck" ON
6. Adjust FOV and Smoothness while in a match

## Anti-ban / anti-blacklist notes

- Package name is disguised as a system optimizer (`com.system.optimizer.service`)
- No injected .so, no memory editing, no known cheat signatures
- Gestures use bezier curves + random delays
- Aim loop runs at irregular intervals
- ProGuard minify + resource shrink enabled on release
- Does not touch Free Fire process memory → far harder for client-side signature scans

Still possible:
- Behavioral detection (perfect tracking over long periods)
- Server-side aim statistics
- Accessibility / MediaProjection abuse flags on heavily monitored accounts

Use a secondary account. Do not stay locked 100% of every fight.

## Tuning the detector

Open `AimEngine.java` → `TARGET_HSV` array.
Free Fire enemy indicators / nameplates change color between versions and graphics settings.
If detection is weak, sample the color of the enemy outline/name in a screenshot and expand the hue ranges.

For stronger detection later: replace `findCandidates()` with a small ONNX model (YOLOv8n / NanoDet) running via onnxruntime-android. The rest of the pipeline stays identical.

## Requirements

- Android 7.0+ (API 24)
- Accessibility permission
- Overlay permission
- MediaProjection (screen capture) permission
