package com.ff.aimbot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.PointF;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;

import java.util.concurrent.atomic.AtomicBoolean;

public class OverlayService extends Service {

    private WindowManager windowManager;
    private View menuView;
    private final AimEngine engine = new AimEngine();
    private final Handler loopHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean looping = new AtomicBoolean(false);

    private int screenW, screenH;
    private float lastAimX, lastAimY;
    private boolean hasLast = false;

    private final Runnable aimLoop = new Runnable() {
        @Override
        public void run() {
            if (!looping.get()) return;
            try {
                if (engine.isEnabled() && CaptureService.isActive() && TouchService.isRunning()) {
                    android.graphics.Bitmap frame = CaptureService.getLatestFrame();
                    if (frame != null && !frame.isRecycled()) {
                        int capW = frame.getWidth();
                        int capH = frame.getHeight();
                        PointF target = engine.process(frame, capW, capH, screenW, screenH);
                        if (target != null) {
                            float fromX = hasLast ? lastAimX : screenW / 2f;
                            float fromY = hasLast ? lastAimY : screenH / 2f;

                            float lerp = engine.getLerpFactor();
                            float toX = fromX + (target.x - fromX) * lerp;
                            float toY = fromY + (target.y - fromY) * lerp;

                            // duration scales with distance for natural feel
                            float dist = (float) Math.hypot(toX - fromX, toY - fromY);
                            int duration = (int) Math.min(90, Math.max(35, dist * 0.45f));

                            TouchService.get().aimTo(fromX, fromY, toX, toY, duration, true);

                            lastAimX = toX;
                            lastAimY = toY;
                            hasLast = true;
                        } else {
                            hasLast = false;
                        }
                    }
                }
            } catch (Throwable ignored) {
            }
            // ~18-22 fps aim loop, jittered
            int next = 45 + (int) (Math.random() * 18);
            loopHandler.postDelayed(this, next);
        }
    };

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(43, buildNotification());

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        lastAimX = screenW / 2f;
        lastAimY = screenH / 2f;

        addOverlay();
        looping.set(true);
        loopHandler.post(aimLoop);
        return START_STICKY;
    }

    private void addOverlay() {
        menuView = LayoutInflater.from(this).inflate(R.layout.overlay_menu, null);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 40;
        params.y = 180;

        Switch swAim = menuView.findViewById(R.id.sw_aim);
        Switch swSmooth = menuView.findViewById(R.id.sw_smooth);
        SeekBar sbFov = menuView.findViewById(R.id.sb_fov);
        SeekBar sbSmooth = menuView.findViewById(R.id.sb_smooth);
        Button btnClose = menuView.findViewById(R.id.btn_close);

        swAim.setOnCheckedChangeListener((b, checked) -> engine.setEnabled(checked));
        sbFov.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { engine.setFov(p); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        sbSmooth.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { engine.setSmoothness(p); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        btnClose.setOnClickListener(v -> menuView.setVisibility(View.GONE));

        // drag the menu
        menuView.setOnTouchListener(new View.OnTouchListener() {
            private int ox, oy;
            private float tx, ty;
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        ox = params.x; oy = params.y;
                        tx = e.getRawX(); ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = ox + (int) (e.getRawX() - tx);
                        params.y = oy + (int) (e.getRawY() - ty);
                        windowManager.updateViewLayout(menuView, params);
                        return true;
                }
                return false;
            }
        });

        windowManager.addView(menuView, params);
        engine.setFov(sbFov.getProgress());
        engine.setSmoothness(sbSmooth.getProgress());
    }

    private Notification buildNotification() {
        String id = "opt_overlay";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(id, "Optimizer", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        return new Notification.Builder(this, id)
                .setContentTitle("System Optimizer")
                .setContentText("Active")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        looping.set(false);
        loopHandler.removeCallbacks(aimLoop);
        if (menuView != null && windowManager != null) {
            try { windowManager.removeView(menuView); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
