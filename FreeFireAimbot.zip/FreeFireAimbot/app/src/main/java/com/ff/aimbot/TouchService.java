package com.ff.aimbot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

public class TouchService extends AccessibilityService {

    private static TouchService instance;
    private static final AtomicBoolean running = new AtomicBoolean(false);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rng = new Random();

    public static boolean isRunning() {
        return running.get() && instance != null;
    }

    public static TouchService get() {
        return instance;
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        running.set(true);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // silent
    }

    @Override
    public void onInterrupt() {
        running.set(false);
        instance = null;
    }

    @Override
    public void onDestroy() {
        running.set(false);
        instance = null;
        super.onDestroy();
    }

    /**
     * Humanized drag from current center toward target (neck point).
     * duration and path jitter reduce detection fingerprint.
     */
    public void aimTo(float fromX, float fromY, float toX, float toY, int baseDurationMs, boolean smooth) {
        if (!running.get()) return;

        float dx = toX - fromX;
        float dy = toY - fromY;
        float dist = (float) Math.hypot(dx, dy);
        if (dist < 4f) return;

        Path path = new Path();
        path.moveTo(fromX, fromY);

        if (smooth) {
            // quadratic bezier with slight random control point for human curve
            float cx = fromX + dx * 0.5f + (rng.nextFloat() - 0.5f) * 18f;
            float cy = fromY + dy * 0.5f + (rng.nextFloat() - 0.5f) * 18f;
            path.quadTo(cx, cy, toX + (rng.nextFloat() - 0.5f) * 3f, toY + (rng.nextFloat() - 0.5f) * 3f);
        } else {
            path.lineTo(toX, toY);
        }

        int duration = baseDurationMs + rng.nextInt(25) - 8;
        if (duration < 40) duration = 40;

        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, duration);

        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(stroke);

        // small random delay before firing gesture (anti pattern)
        int delay = rng.nextInt(18);
        handler.postDelayed(() -> {
            if (running.get()) {
                dispatchGesture(builder.build(), null, null);
            }
        }, delay);
    }

    /** Single tap (for optional fire assist) */
    public void tap(float x, float y) {
        if (!running.get()) return;
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, 40 + rng.nextInt(30));
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(stroke);
        dispatchGesture(b.build(), null, null);
    }
}
