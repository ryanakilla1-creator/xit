package com.ff.aimbot;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 1001;
    private static final int REQ_CAPTURE = 1002;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);

        findViewById(R.id.btn_overlay).setOnClickListener(v -> requestOverlay());
        findViewById(R.id.btn_accessibility).setOnClickListener(v -> openAccessibility());
        findViewById(R.id.btn_capture).setOnClickListener(v -> requestCapture());
        findViewById(R.id.btn_start).setOnClickListener(v -> startServices());

        updateStatus();
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQ_OVERLAY);
        } else {
            Toast.makeText(this, "Overlay already granted", Toast.LENGTH_SHORT).show();
        }
    }

    private void openAccessibility() {
        Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        startActivity(i);
        Toast.makeText(this, "Enable 'System Optimizer' service", Toast.LENGTH_LONG).show();
    }

    private void requestCapture() {
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    private void startServices() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Enable overlay first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!TouchService.isRunning()) {
            Toast.makeText(this, "Enable Accessibility first", Toast.LENGTH_SHORT).show();
            return;
        }
        startService(new Intent(this, OverlayService.class));
        Toast.makeText(this, "Aim service running. Open Free Fire.", Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent svc = new Intent(this, CaptureService.class);
            svc.putExtra("resultCode", resultCode);
            svc.putExtra("data", data);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svc);
            } else {
                startService(svc);
            }
            Toast.makeText(this, "Capture granted", Toast.LENGTH_SHORT).show();
        }
        updateStatus();
    }

    private void updateStatus() {
        StringBuilder sb = new StringBuilder();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            sb.append("Overlay: ").append(Settings.canDrawOverlays(this) ? "OK" : "OFF").append("\n");
        }
        sb.append("Accessibility: ").append(TouchService.isRunning() ? "OK" : "OFF").append("\n");
        sb.append("Capture: ").append(CaptureService.isActive() ? "OK" : "OFF");
        status.setText(sb.toString());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }
}
