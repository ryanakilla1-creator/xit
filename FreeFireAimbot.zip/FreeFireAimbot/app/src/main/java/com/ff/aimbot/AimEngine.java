package com.ff.aimbot;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * External vision-based neck lock for Free Fire style games.
 * Detects candidate enemy regions via color + density heuristics,
 * then locks aim point to upper ~22% of the bounding box (neck/head junction).
 *
 * This is the non-memory path: works without root, survives most signature
 * scans that look for injected libraries or known memory patterns.
 */
public class AimEngine {

    private final Random rng = new Random();

    // Tunable color ranges (Free Fire enemy nameplate / outline often sit in
    // saturated reds / oranges / certain HUD colors — adjust per version)
    private static final float[][] TARGET_HSV = {
            // hue min, hue max, sat min, val min
            {0f, 18f, 0.45f, 0.35f},   // red-ish
            {340f, 360f, 0.45f, 0.35f},
            {20f, 45f, 0.50f, 0.40f},  // orange/yellow name tags
    };

    private int fovRadiusPx = 280;
    private float smoothness = 0.35f; // 0 = instant, 1 = very slow
    private boolean enabled = false;

    public void setFov(int percent) {
        // map 0-100 slider to ~80..420 px radius (half-res capture)
        fovRadiusPx = 80 + (int) (percent * 3.4f);
    }

    public void setSmoothness(int percent) {
        smoothness = percent / 100f;
    }

    public void setEnabled(boolean v) {
        enabled = v;
    }

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Main entry. Returns the neck target in screen coordinates (full res),
     * or null if nothing in FOV.
     *
     * captureW/H = size of the bitmap we receive (half res)
     * screenW/H  = real device resolution for touch mapping
     */
    public PointF process(Bitmap frame, int captureW, int captureH, int screenW, int screenH) {
        if (!enabled || frame == null || frame.isRecycled()) return null;

        List<RectF> candidates = findCandidates(frame, captureW, captureH);
        if (candidates.isEmpty()) return null;

        // center of FOV (screen center mapped to capture space)
        float cx = captureW / 2f;
        float cy = captureH / 2f;

        RectF best = null;
        float bestDist = Float.MAX_VALUE;

        for (RectF r : candidates) {
            float midX = r.centerX();
            float midY = r.centerY();
            float d = (float) Math.hypot(midX - cx, midY - cy);
            if (d < fovRadiusPx && d < bestDist) {
                bestDist = d;
                best = r;
            }
        }

        if (best == null) return null;

        // Neck lock: aim at ~22% from top of the box (head/neck)
        float neckX = best.centerX();
        float neckY = best.top + best.height() * 0.22f;

        // map back to full screen coordinates
        float scaleX = (float) screenW / captureW;
        float scaleY = (float) screenH / captureH;

        float targetX = neckX * scaleX;
        float targetY = neckY * scaleY;

        // slight human jitter so it never lands on the exact same pixel every frame
        targetX += (rng.nextFloat() - 0.5f) * 2.2f;
        targetY += (rng.nextFloat() - 0.5f) * 2.2f;

        return new PointF(targetX, targetY);
    }

    /**
     * Very lightweight candidate finder.
     * Scans for saturated color blobs of plausible player size.
     * Real production builds replace this with a tiny ONNX detector.
     */
    private List<RectF> findCandidates(Bitmap bmp, int w, int h) {
        List<RectF> out = new ArrayList<>();
        // sample every 4th pixel for speed
        int step = 4;
        boolean[][] visited = new boolean[h / step + 1][w / step + 1];

        for (int y = 0; y < h; y += step) {
            for (int x = 0; x < w; x += step) {
                if (visited[y / step][x / step]) continue;
                int pixel = bmp.getPixel(x, y);
                if (matchesTarget(pixel)) {
                    RectF box = floodApprox(bmp, x, y, w, h, step, visited);
                    if (box != null && isPlausiblePlayer(box, w, h)) {
                        out.add(box);
                    }
                }
            }
        }
        return out;
    }

    private boolean matchesTarget(int color) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        float hue = hsv[0];
        float sat = hsv[1];
        float val = hsv[2];
        for (float[] range : TARGET_HSV) {
            if (hue >= range[0] && hue <= range[1] && sat >= range[2] && val >= range[3]) {
                return true;
            }
        }
        return false;
    }

    private RectF floodApprox(Bitmap bmp, int sx, int sy, int w, int h, int step, boolean[][] visited) {
        int minX = sx, maxX = sx, minY = sy, maxY = sy;
        int count = 0;
        // simple bounded region grow (not full flood fill — keep it cheap)
        for (int dy = -40; dy <= 40; dy += step) {
            for (int dx = -25; dx <= 25; dx += step) {
                int nx = sx + dx;
                int ny = sy + dy;
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                int ix = nx / step;
                int iy = ny / step;
                if (visited[iy][ix]) continue;
                if (matchesTarget(bmp.getPixel(nx, ny))) {
                    visited[iy][ix] = true;
                    minX = Math.min(minX, nx);
                    maxX = Math.max(maxX, nx);
                    minY = Math.min(minY, ny);
                    maxY = Math.max(maxY, ny);
                    count++;
                }
            }
        }
        if (count < 6) return null;
        return new RectF(minX, minY, maxX, maxY);
    }

    private boolean isPlausiblePlayer(RectF r, int frameW, int frameH) {
        float bw = r.width();
        float bh = r.height();
        if (bw < 8 || bh < 12) return false;
        if (bw > frameW * 0.35f || bh > frameH * 0.45f) return false;
        float ratio = bh / Math.max(bw, 1f);
        return ratio > 1.1f && ratio < 4.5f; // vertical-ish human shape
    }

    /**
     * Smooth interpolation factor applied by the service loop.
     * Returns how much of the delta to apply this frame.
     */
    public float getLerpFactor() {
        // higher smoothness = smaller steps
        return Math.max(0.08f, 1f - smoothness);
    }
}
